#!/usr/bin/env python3
"""Шесть ботов садятся за стол и играют — быстрый способ увидеть, что сервер жив.

Ботам не нужен Unity: они делают ровно то же, что будет делать клиент —
берут гостевой токен по HTTP, открывают WebSocket, шлют ``quick_join`` и
отвечают на ``action_required``.

Запуск (сервер должен быть поднят)::

    python scripts/bot_client.py --bots 6 --hands 10 --stake low
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import urllib.request

try:
    import websockets
except ImportError:  # pragma: no cover
    print("Нужен пакет websockets:  pip install websockets", file=sys.stderr)
    raise SystemExit(1) from None


class Lcg:
    """Детерминированный источник решений — прогон всегда воспроизводится."""

    def __init__(self, seed: int) -> None:
        self.state = seed

    def next(self, bound: int) -> int:
        self.state = (self.state * 6364136223846793005 + 1442695040888963407) % (1 << 64)
        return (self.state >> 33) % bound


def get_token(base_url: str, nickname: str) -> str:
    request = urllib.request.Request(
        f"{base_url}/auth/guest",
        data=json.dumps({"nickname": nickname}).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.load(response)["token"]


async def bot(index: int, base_url: str, ws_url: str, stake: str, hands: int, quiet: bool) -> None:
    nickname = f"Бот-{index}"
    token = get_token(base_url, nickname)
    rng = Lcg(1000 + index)
    finished = 0

    async with websockets.connect(f"{ws_url}/ws?token={token}") as ws:
        await ws.send(json.dumps({"t": "quick_join", "d": {"stake": stake}}))

        async for raw in ws:
            message = json.loads(raw)
            kind, data = message.get("t"), message.get("d", {})

            if kind == "joined_table" and not quiet:
                print(f"[{nickname}] сел за {data['table']['table_id']}, место {data['you']['seat_no']}")

            elif kind == "action_required" and data.get("options"):
                await asyncio.sleep(0.15 + rng.next(40) / 100)
                options = {o["action"]: o for o in data["options"]}
                choice = _decide(options, rng)
                await ws.send(
                    json.dumps(
                        {
                            "t": "action",
                            "d": {
                                "hand_id": data.get("hand_id"),
                                "action": choice[0],
                                "amount": choice[1],
                            },
                        }
                    )
                )

            elif kind == "hand_finished":
                finished += 1
                if index == 0 and not quiet:
                    winners = ", ".join(
                        f"место {w['seat_no']} +{w['amount']}"
                        + (f" ({w['combination']})" if w.get("combination") else "")
                        for w in data["winners"]
                    )
                    board = " ".join(data["board"]) or "—"
                    print(f"  раздача {finished}: борд [{board}] банк {data['total_pot']} → {winners}")
                if finished >= hands:
                    await ws.send(json.dumps({"t": "leave_table", "d": {}}))
                    return

            elif kind == "error":
                print(f"[{nickname}] ошибка: {data.get('code')} — {data.get('message')}")


def _decide(options: dict, rng: Lcg) -> tuple[str, int]:
    roll = rng.next(100)
    if "check" in options:
        if roll < 65:
            return "check", 0
        if "bet" in options:
            spec = options["bet"]
            span = max(1, spec["max_amount"] - spec["min_amount"])
            return "bet", spec["min_amount"] + rng.next(min(span, spec["min_amount"] * 3 or span))
        return "check", 0
    if roll < 20:
        return "fold", 0
    if roll < 88 and "call" in options:
        return "call", 0
    if "raise" in options:
        spec = options["raise"]
        span = max(1, spec["max_amount"] - spec["min_amount"])
        return "raise", spec["min_amount"] + rng.next(min(span, spec["min_amount"] * 2 or span))
    return "call" if "call" in options else "fold", 0


async def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="localhost:8000")
    parser.add_argument("--bots", type=int, default=6)
    parser.add_argument("--hands", type=int, default=10)
    parser.add_argument("--stake", default="low")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    base_url = f"http://{args.host}"
    ws_url = f"ws://{args.host}"
    print(f"Запускаю {args.bots} ботов на {base_url}, уровень ставок {args.stake}…")

    await asyncio.gather(
        *(
            bot(i, base_url, ws_url, args.stake, args.hands, args.quiet)
            for i in range(args.bots)
        )
    )
    print("Готово.")


if __name__ == "__main__":
    asyncio.run(main())
